package com.example.notetakingapp;

public class Note {
    private String content;

}
